const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 9034;
const PUBLIC_DIR = path.join(__dirname, 'public');

const server = http.createServer(async (req, res) => {
  try {
    // 处理 JSON 配置请求
    if (req.url === '/deta.json') {
      const jsonPath = path.join(PUBLIC_DIR, 'deta.json');
      const data = await fs.promises.readFile(jsonPath, 'utf8');
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(data);
      return;
    }

    // 处理其他静态文件
    const filePath = req.url === '/' ? 
      path.join(PUBLIC_DIR, 'index.html') : 
      path.join(PUBLIC_DIR, req.url);
    
    const extname = path.extname(filePath);
    let contentType = 'text/html';

    switch (extname) {
      case '.js':
        contentType = 'text/javascript';
        break;
      case '.css':
        contentType = 'text/css';
        break;
      case '.json':
        contentType = 'application/json';
        break;
    }

    const data = await fs.promises.readFile(filePath, 'utf8');
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  } catch (error) {
    if (error.code === 'ENOENT') {
      res.writeHead(404);
      res.end('Not Found');
    } else {
      res.writeHead(500);
      res.end('Server Error');
    }
  }
});

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
});