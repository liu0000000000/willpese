const fs = require('fs/promises');
const path = require('path');

/**
 * 删除share文件夹下的指定名称子文件夹
 * @param {string} folderName 要删除的文件夹名称
 */
async function deleteFolderByName(folderName) {
  try {
    // 1. 验证输入参数
    if (!folderName || typeof folderName !== 'string') {
      throw new Error('文件夹名称必须是有效字符串');
    }

    // 2. 构造完整路径（安全处理路径拼接）
    const sharePath = path.join(process.cwd(), 'share');
    const targetPath = path.join(sharePath, folderName);

    // 3. 安全检查：确保路径仍在share目录内
    if (!targetPath.startsWith(sharePath)) {
      throw new Error('安全限制：不能删除share目录外的文件夹');
    }

    // 4. 执行删除操作
    console.log(`正在删除文件夹: ${targetPath}`);
    await fs.rm(targetPath, { recursive: true, force: true });
    
    console.log(`成功删除文件夹: ${folderName}`);
    return { success: true, path: targetPath };
  } catch (error) {
    console.error(`删除文件夹失败: ${error.message}`);
    return { 
      success: false, 
      error: error.message,
      code: error.code // 包含系统错误代码(如ENOENT)
    };
  }
}

// 使用示例
(async () => {
  // 示例1: 删除名为"test"的文件夹







  const data = await fs.readFile('d.bin', 'utf8');
  const name = data.trim();
  const result = await deleteFolderByName(name);
  
  // 示例2: 处理结果
  if (!result.success) {
    if (result.code === 'ENOENT') {
      console.log('文件夹不存在，无需删除');
    } else {
      console.log('删除操作失败，需要人工干预');
    }
  }
})();