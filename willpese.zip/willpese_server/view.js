const { spawn } = require('child_process');
const path = require('path');

const portData = require('./port.json');
const port0 = portData.port.view;

// 配置参数
const config = {
  folder: path.join(__dirname, 'share'), // 要托管的文件夹（默认 ./public）

  port: port0,                      // 端口号
  watch: true,                           // 是否监听文件变化
  cors: true,                            // 是否启用 CORS
  open: false                            // 是否自动打开浏览器
};

// 生成 http-server 的命令行参数
const args = [
  'http-server',
  config.folder,                         // 指定文件夹
  '-p', config.port.toString(),          // 设置端口
];
if (config.watch) args.push('--watch');  // 启用监听
if (config.cors) args.push('--cors');    // 启用 CORS
if (config.open) args.push('--open');    // 自动打开浏览器

// 启动服务器
const server = spawn('npx', args, {
  stdio: 'inherit',  // 继承父进程的输入输出（方便调试）
  shell: true,       // 兼容 Windows
  detached: true     // 让进程独立运行
});

// 错误处理
server.on('error', (err) => {
  console.error('❌ 启动服务器失败:', err);
});

// 退出事件
server.on('close', (code) => {
  console.log(`🚨 服务器进程退出，代码 ${code}`);
});

// 输出启动信息
console.log(`🚀 启动 http-server，访问：http://localhost:${config.port}`);
console.log(`📂 托管目录：${config.folder}`);