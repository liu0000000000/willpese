const http = require('http');
const url = require('url');
const querystring = require('querystring');
const fs = require('fs');
const { exec } = require('child_process');

// 文件路径
const DATA_FILE = 'd.bin';
const SCRIPT_FILE = 'd.js';

// 尝试从文件加载已有数据
let userInput = '';
try {
  userInput = fs.readFileSync(DATA_FILE, 'utf8');
} catch (err) {
  // 如果文件不存在，创建一个空文件
  if (err.code === 'ENOENT') {
    fs.writeFileSync(DATA_FILE, '');
  } else {
    console.error('读取文件错误:', err);
  }
}

// 创建 HTTP 服务器
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url);
  const path = parsedUrl.pathname;
  
  // 处理 POST 请求（表单提交）
  if (req.method === 'POST' && path === '/submit') {
    let body = '';
    
    req.on('data', chunk => {
      body += chunk.toString();
    });
    
    req.on('end', () => {
      const postData = querystring.parse(body);
      userInput = postData.userText || '';
      
      // 保存到文件
      fs.writeFile(DATA_FILE, userInput, (err) => {
        if (err) {
          console.error('保存文件错误:', err);
          res.writeHead(500);
          return res.end('保存失败');
        }
        
        // 运行 d.js 脚本
        exec(`node ${SCRIPT_FILE}`, (error, stdout, stderr) => {
          let executionResult = '';
          if (error) {
            console.error(`执行错误: ${error}`);
            executionResult = `执行错误: ${error.message}`;
          } else if (stderr) {
            console.error(`脚本错误: ${stderr}`);
            executionResult = `脚本错误: ${stderr}`;
          } else {
            console.log(`脚本输出: ${stdout}`);
            executionResult = `脚本输出: ${stdout}`;
          }
          
          // 将执行结果保存到响应中
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(`
            <!DOCTYPE html>
            <html>
            <head>
              <title></title>
              <meta http-equiv="refresh" content="3;url=/" />
              <style>
                body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
                .message { padding: 15px; background: #d4edda; color: #155724; margin: 20px 0; }
              </style>
            </head>
            <body>
              <h1>操作成功</h1>
              <div class="message">
                <p>准备删除 ${DATA_FILE}</p>
                <p>${executionResult}</p>
                <p>3秒后自动返回...</p>
              </div>
            </body>
            </html>
          `);
        });
      });
    });
    
    return;
  }
  
  // 处理 GET 请求（显示页面）
  if (req.method === 'GET' && path === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    
    const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <title></title>
      <style>
        body {
          font-family: Arial, sans-serif;
          max-width: 800px;
          margin: 0 auto;
          padding: 20px;
        }
        textarea {
          width: 100%;
          height: 100px;
          margin-bottom: 10px;
        }
        button {
          padding: 8px 16px;
          background: #007bff;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          margin-right: 10px;
        }
        .input-display {
          margin-top: 20px;
          padding: 10px;
          border: 1px solid #ddd;
          background: #f9f9f9;
          min-height: 50px;
          white-space: pre-wrap;
        }
        .file-path {
          margin-top: 20px;
          color: #666;
          font-size: 0.9em;
        }
        .button-group {
          margin: 15px 0;
        }
      </style>
    </head>
    <body>
      <h1></h1>
      <form method="POST" action="/submit">
        <textarea name="userText" placeholder="在这里输入删除内容...">${userInput}</textarea>
        <br>
        <div class="button-group">
          <button type="submit">删除</button>
        </div>
      </form>
      <div>
        <div class="file-path">脚本文件: ${SCRIPT_FILE}</div>         
      </div>
    </body>
    </html>
    `;
    
    res.end(html);
    return;
  }
  
  // 其他路由返回 404
  res.writeHead(404);
  res.end('Not Found');
});

// 启动服务器

const portData = require('./port.json');
const port0 = portData.port.pull;
const PORT = port0;
server.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
  console.log(`用户输入将保存到: ${DATA_FILE}`);
  console.log(`点击保存按钮将运行: ${SCRIPT_FILE}`);
});